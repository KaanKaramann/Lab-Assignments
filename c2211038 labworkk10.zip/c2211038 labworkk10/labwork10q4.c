#include <stdio.h>
#include <math.h>

int isPrime(int n) {
    if (n <= 1) {
        return 0;
    }

    for (int i = 2; i <= sqrt(n); i++) {
        if (n % i == 0) {
            return 0;
        }
    }

    return 1; 
}

int isArmstrong(int n) {
    int onum, remainder, result = 0, ddigits = 0;

    onum = n;

    while (onum != 0) {
        onum /= 10;
        ddigits++;
    }

    onum = n;

    while (onum != 0) {
        remainder = onum % 10;
        result += pow(remainder, ddigits);
        onum /= 10;
    }

    return (result == n); 
}

int main() {
    int num;

    printf("Enter a number: ");
    scanf("%d", &num);

    if (isPrime(num)) {
        printf("%d is a prime number.\n", num);
    } else {
        printf("%d is not a prime number.\n", num);
    }

    if (isArmstrong(num)) {
        printf("%d is an Armstrong number.\n", num);
    } else {
        printf("%d is not an Armstrong number.\n", num);
    }

    return 0;
}
