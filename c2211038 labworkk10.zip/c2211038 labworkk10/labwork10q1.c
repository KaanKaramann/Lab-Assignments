#include <stdio.h>

int isVowel(char ch) {

    switch (ch) {
        case 'a':
        case 'e':
        case 'i':
        case 'o':
        case 'u':
        case 'A':
        case 'E':
        case 'I':
        case 'O':
        case 'U':
            return 1;
        default:
            return 0; 
    }
}

int main() {
    printf("Enter 20 characters consecutively: ");
    
    char user_input[21];
    fgets(user_input, sizeof(user_input), stdin);

    int vcount = 0;

    for (int i = 0; i < 20; i++) {
        vcount += isVowel(user_input[i]);
    }

    printf("Number of vowels among the 20 characters: %d\n", vcount);

    return 0;
}
