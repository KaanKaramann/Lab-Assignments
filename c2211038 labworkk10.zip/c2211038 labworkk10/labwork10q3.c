#include <stdio.h>
#include <math.h>

void calculateFormula(int a, int b, int c) {
    double result = ((5 *a/3.0) + (pow(b, 2) / 5.0) - ((pow(c, 2) - 1) / 2.0));
    printf("Result for a=%d, b=%d, c=%d: %.2f\n", a, b, c, result);
}

int main() {
    int a, b, c;

    for (int i = 1; i <= 5; i++) {
        printf("Enter integers (a b c) for set #%d: ", i);

        scanf("%d %d %d", &a, &b, &c);

        calculateFormula(a, b, c);
    }

    return 0;
}
