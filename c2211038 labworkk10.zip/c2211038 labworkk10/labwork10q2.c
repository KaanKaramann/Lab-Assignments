#include <stdio.h>

void fibonacciSeries(int n) {
    int a = 0, c = 1, b;

    printf("Fibonacci Series terms:\n", n);

    for (int i = 0; i < n; i++) {
        printf("%d, ", a);

        b = a + c;
        a = c;
        c = b;
    }

    printf("\n");
}

int main() {
    int range;

    printf("Fibonacci series: ");
    scanf("%d", &range);

    fibonacciSeries(range);

    return 0;
}
